const STYLE='clean';
/* EPISODE coldman: why a man walks on a broken bone but "dies" from a cold.
   Scene code below uses ORIGINAL voice seconds. The clip plays at 1.25x with two pauses removed:
   M() maps original -> real time (WIN, timing.json) and INV() maps real -> original (scene code).
   Values the library reads: WIN SC GLW CRT_T0 HUD_END DMIN. */
const HUD_END=0,CRT_T0=9999,GLW=[];
function DMIN(t){return 0}
const SPEED=1.25,CUTS=[[45.55,46.56],[50.17,51.16]];
const M=t=>{let r=0;CUTS.forEach(c=>{r+=Math.min(Math.max(t-c[0],0),c[1]-c[0])});return(t-r)/SPEED};
const INV=tn=>{let t=tn*SPEED;CUTS.forEach(c=>{if(t>=c[0])t+=c[1]-c[0]});return t};
const RD='#ff5a4a',BL='#6ea8ff',PK='#ff8ec7',GN='#3f9a3f';
/* scene windows sit in the silences between voice chunks (original seconds) */
const WIN=[[0,5.0],[5.0,10.45],[10.45,15.2],[15.2,29.0],[29.0,36.0],[36.0,40.5],[40.5,53.7],[53.7,61.0],[61.0,69.0],[69.0,77.7],[77.7,87.4]].map(w=>[M(w[0]),M(w[1])]);
let TR=0;

/* ---------- karaoke subtitles: spoken word = yellow + underline, finished = white, coming = grey ---------- */
(function(){const st=document.createElement('style');st.textContent='.wd.up{color:#8d8d8d}.wd.done{color:#fff}.wd.cur{color:#ffd84a;text-decoration:underline;text-decoration-thickness:7px;text-underline-offset:13px;text-decoration-skip-ink:none}';document.head.appendChild(st)})();
function subs(t){if(SB){sub.style.opacity=0;return}const Ls=TM.lines;let idx=-1;for(let i=0;i<Ls.length;i++){if(t>=Ls[i][0]&&t<Ls[i][1]-.02){idx=i;break}}
 const key=idx<0?'':String(idx);
 if(key!==curKey){curKey=key;subin.innerHTML='';words=[];if(idx>=0){const toks=SUBS[idx].replace(/\*/g,'').split(' ').filter(Boolean),wt=toks.map(q=>Math.max(2,q.replace(/[\u200c\u200f.,،:؟?!«»]/g,'').length)),tot=wt.reduce((a,b)=>a+b,0),a=Ls[idx][0],b=Ls[idx][1];let c=a;
  words.tm=[];toks.forEach((q,j)=>{const d=(b-a)*wt[j]/tot;words.tm.push([c,c+d]);c+=d;const w=document.createElement('span');w.className='wd up';w.textContent=q;subin.appendChild(w);subin.appendChild(document.createTextNode(' '));words.push(w)})}}
 if(idx>=0){const a=Ls[idx][0],b=Ls[idx][1];words.forEach((w,j)=>{const m=words.tm[j],tc=t+.04;w.className='wd '+(tc>=m[1]?'done':(tc>=m[0]?'cur':'up'))});sub.style.opacity=P(t,a-.02,.1)*(1-P(t,b-.1,.08))}else sub.style.opacity=0}

/* ---------- small helpers ---------- */
const ez=(t,a,d)=>oC(P(t,a,d)),pp=(t,a,d)=>oB(P(t,a,d),2);
function popAt(cx,cy,k,fn){g.save();g.translate(cx,cy);g.scale(k,k);g.translate(-cx,-cy);fn();g.restore()}
function gnd(y,p,sc,al){al=al===undefined?1:al;S([[40,y],[1040,y]],{w:8,p:p,a:.95*al,seed:90,wob:2.8});
 if(p>=1)for(let i=0;i<7;i++){const xx=(((i*170-sc)%1190)+1190)%1190-70;if(xx>40&&xx<1000)S([[xx,y+26],[xx+46,y+26]],{w:5,a:.3*al,seed:100+i,wob:1})}}
function mg(o){return fig(Object.assign({mg:true},o))}
function wm(o){const s=o.s||1,p=o.p===undefined?1:o.p,al=o.a===undefined?1:o.a,f=fig(Object.assign({mg:false},o)),hc=f.hc,hr=f.hr,sd=o.seed||5;
 if(p>.3){const q=cl((p-.3)/.4),o2={p:q,a:al,w:7*s,seed:sd+50,wob:1.4};
  [-1,1].forEach((d,i)=>S([[hc[0]+d*hr*.98,hc[1]-hr*.1],[hc[0]+d*hr*1.18,hc[1]+hr*.8],[hc[0]+d*hr*.9,hc[1]+hr*1.9],[hc[0]+d*hr*.62,hc[1]+hr*2.05]],Object.assign({},o2,{seed:sd+50+i})));
  S(circ(hc[0],hc[1],hr*1.1,18,Math.PI*1.04,Math.PI*1.96),Object.assign({},o2,{seed:sd+53}));S([[hc[0]-hr*.1,hc[1]-hr*1.08],[hc[0]+hr*.55,hc[1]-hr*.55]],Object.assign({},o2,{seed:sd+54,w:5*s}))}
 if(p>.55){const q=cl((p-.55)/.3),hp=[f.hip[0],f.hip[1]];S([[hp[0]-14*s,hp[1]-40*s],[hp[0]-78*s,hp[1]+66*s],[hp[0]+78*s,hp[1]+66*s],[hp[0]+14*s,hp[1]-40*s]],{p:q,a:al,w:8*s,seed:sd+60,wob:1.6})}
 return f}
function legs(ph,k){const a=Math.sin(ph)*.48*k,b=Math.sin(ph+Math.PI)*.48*k;return{L:[a,a-.5*Math.max(0,Math.cos(ph))*k],R:[b,b-.5*Math.max(0,Math.cos(ph+Math.PI))*k]}}
function bone(cx,cy,len,rot,p,al,cr){cr=cr||0;al=al===undefined?1:al;const c=Math.cos(rot),s=Math.sin(rot),T=(u,v)=>[cx+u*c-v*s,cy+u*s+v*c],h=len/2,kr=len*.08,th=len*.05,gp=cr*len*.03,o={w:8,a:al,p:p,wob:1.4};
 [-1,1].forEach((sd,i)=>[-1,1].forEach((sv,j)=>{const q=T(sd*h,sv*kr*.85);S(circ(q[0],q[1],kr,14,-1.5,-1.5+TAU),Object.assign({},o,{seed:3+i*2+j}))}));
 [-1,1].forEach((sv,j)=>{S([T(-h+kr*.3,sv*th),T(-gp,sv*th)],Object.assign({},o,{seed:12+j}));S([T(gp,sv*th),T(h-kr*.3,sv*th)],Object.assign({},o,{seed:14+j}))});
 if(cr>0)S([T(0,-th*2.6),T(7,-th*1.2),T(-6,0),T(7,th*1.2),T(0,th*2.6)],{col:RD,w:9,p:cl(cr),a:al,seed:20,wob:.6})}
function meter(x0,y0,w,h,lv,col,label,p,al){al=al===undefined?1:al;S(rr(x0,y0,w,h,16),{w:7,p:cl(p),a:al,seed:(x0|0)+7,wob:1.2});
 if(lv>0&&p>.6){g.save();g.globalAlpha=al*.88*cl((p-.6)*3);g.fillStyle=col;const fh=(h-22)*lv;g.beginPath();g.rect(x0+11,y0+h-11-fh,w-22,fh);g.fill();g.restore()}
 if(label)CT(label,x0+w/2,y0+h+44,34,WH,cl((p-.5)*2)*al)}
function tag(str,cx,cy,col,p,sz,al){if(p<=0)return;sz=sz||38;al=al===undefined?1:al;g.save();g.font='800 '+sz+'px V';const w=g.measureText(str).width+60,h=sz*1.65;g.restore();
 S(rr(cx-w/2,cy-h/2,w,h,22),{col:col,w:6,p:cl(p/.55),a:al,seed:(cx*3)|0,wob:1.2});CT(str,cx,cy+3,sz,col,cl((p-.45)/.5)*al)}
function virus(cx,cy,r,t,al,sd){al=al===undefined?1:al;const a0=t*.9+sd;S(circ(cx,cy,r,14),{col:GR,w:6,a:al,seed:sd,wob:.7});
 for(let k=0;k<8;k++){const a=a0+k/8*TAU,c=Math.cos(a),s=Math.sin(a);S([[cx+c*r,cy+s*r],[cx+c*r*1.55,cy+s*r*1.55]],{col:GR,w:5,a:al,seed:sd+k,wob:.3});S(circ(cx+c*r*1.72,cy+s*r*1.72,r*.17,6),{col:GR,w:5,a:al,seed:sd+10+k,wob:.2})}}
function shield(cx,cy,w,h,col,p,al,sd){al=al===undefined?1:al;const pts=[[cx,cy-h/2],[cx+w/2,cy-h/4],[cx+w/2,cy+h/4],[cx,cy+h/2],[cx-w/2,cy+h/4],[cx-w/2,cy-h/4],[cx,cy-h/2]];
 S(pts,{col:col,w:9,p:p,a:al,seed:sd||5,wob:1.6});if(p>=1){g.save();g.globalAlpha=.09*al;g.fillStyle=col;g.beginPath();pts.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.fill();g.restore()}}
function thermo(cx,top,h,lv,col,p,al,sd){al=al===undefined?1:al;const w=38,R=36,by=top+h+R*.6,jy=by-Math.sqrt(R*R-(w/2)*(w/2));
 S([[cx-w/2,jy],[cx-w/2,top+w/2]].concat(circ(cx,top+w/2,w/2,12,Math.PI,TAU)).concat([[cx+w/2,top+w/2],[cx+w/2,jy]]),{w:7,p:cl(p),a:al,seed:sd||4,wob:1});
 S(circ(cx,by,R,26,-Math.PI/2+.58,-Math.PI/2+TAU-.58),{w:7,p:cl(p),a:al,seed:(sd||4)+1,wob:1});
 for(let i=0;i<5;i++)S([[cx+w/2+6,top+26+i*(jy-top-40)/4],[cx+w/2+22,top+26+i*(jy-top-40)/4]],{w:4,a:al*.5,p:cl(p*2-1),seed:(sd||4)+5+i,wob:.5});
 if(p>.7){g.save();g.globalAlpha=al*.92*cl((p-.7)*4);g.fillStyle=col;g.beginPath();g.arc(cx,by,R-9,0,TAU);g.fill();const top0=top+w/2,fh=(jy+4-top0)*lv;g.fillRect(cx-7,jy+4-fh,14,fh);g.restore()}}
function dna(cx,y0,y1,t,p,al){al=al===undefined?1:al;const n=24,A=[],B=[];
 for(let i=0;i<=n;i++){const k=i/n;if(k>p)break;const y=lp(y0,y1,k),ph=k*TAU*2.1+t*1.5,sx=Math.sin(ph)*52;A.push([cx+sx,y,Math.cos(ph)]);B.push([cx-sx,y,Math.cos(ph)])}
 A.forEach((q,i)=>{const b=B[i];S([[q[0],q[1]],[b[0],b[1]]],{col:i%2?YE:WH,w:4,a:al*(.25+.3*Math.abs(q[2])),seed:30+i,wob:.3,steady:true});S(circ(q[0],q[1],7,8),{col:BL,w:6,a:al,seed:60+i,wob:.2,steady:true});S(circ(b[0],b[1],7,8),{col:PK,w:6,a:al,seed:90+i,wob:.2,steady:true})});
 S(A,{col:BL,w:6,a:al*.8,seed:3,wob:.4,steady:true});S(B,{col:PK,w:6,a:al*.8,seed:4,wob:.4,steady:true})}
function tissue(px,py,rot,sz,al){g.save();g.translate(px,py);g.rotate(rot);g.globalAlpha=.92*al;g.fillStyle='#f4f2ea';g.fillRect(-sz/2,-sz/2,sz,sz);g.globalAlpha=.6*al;g.strokeStyle='#8a8678';g.lineWidth=3;g.beginPath();g.moveTo(-sz/2,sz*.05);g.lineTo(sz/2,-sz*.1);g.stroke();g.restore()}
function cloud(cx,cy,rx,ry,p,al){const pts=[];for(let i=0;i<=72;i++){const a=i/72*TAU,b=1+.09*Math.cos(a*8);pts.push([cx+Math.cos(a)*rx*b,cy+Math.sin(a)*ry*b])}
 g.save();g.globalAlpha=.55*al*cl((p-.4)*2);g.fillStyle='#4a2a55';g.beginPath();pts.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.fill();g.restore();
 S(pts,{w:8,p:p,a:al,seed:11,wob:1.5});const q=cl((p-.5)*2);
 [[-.5,-.25],[.5,-.3]].forEach((o,i)=>{const pt=[];for(let k=0;k<=14;k++){const u=k/14;pt.push([cx+o[0]*rx+Math.sin(u*TAU*1.5+i)*rx*.12,cy+(u-.5)*ry*1.2+o[1]*ry*.3])}S(pt,{col:PK,w:6,a:.5*al,p:q,seed:12+i,wob:1})});
 S([[cx,cy-ry*.7],[cx+8,cy-ry*.2],[cx-8,cy+ry*.2],[cx,cy+ry*.65]],{col:PK,w:6,a:.45*al,p:q,seed:13,wob:1})}
function sparkle(cx,cy,r,al,sd,rot,col){rot=rot||0;[0,1].forEach(i=>{const a=rot+i*Math.PI/2;S([[cx-Math.cos(a)*r,cy-Math.sin(a)*r],[cx+Math.cos(a)*r,cy+Math.sin(a)*r]],{col:col||YE,w:6,a:al,seed:sd+i,wob:.2,steady:true})})}
function puff(px,py,u,al){S(circ(px,py,8+18*u,10),{w:5,a:al*(1-u)*.55,seed:700+((px*3)|0)%50,wob:.6})}
function ab(cx,cy,sz,rot,col,al){const R=q=>[cx+(q[0]*Math.cos(rot)-q[1]*Math.sin(rot))*sz,cy+(q[0]*Math.sin(rot)+q[1]*Math.cos(rot))*sz];
 S([R([0,1]),R([0,0]),R([-.75,-.85])],{col:col,w:6,a:al,seed:3,wob:.2,steady:true});S([R([0,0]),R([.75,-.85])],{col:col,w:6,a:al,seed:4,wob:.2,steady:true})}
const TSS=(()=>{const r=rng(41),a=[];for(let i=0;i<9;i++)a.push({a:-.4-r()*2.3,v:210+r()*260,rot:r()*TAU,w:(r()-.5)*5,sz:30+r()*16,ph:r()});return a})();
function tissues(t,t0,hx,hy,al){TSS.forEach((o,i)=>{const u=((t-t0)*.55+o.ph)%1,tt=u*1.6;if(t<t0)return;const k=cl(u*6)*(1-P(u,.8,.2));
 tissue(hx+Math.cos(o.a)*o.v*tt,hy+Math.sin(o.a)*o.v*tt+420*tt*tt*.5,o.rot+o.w*tt,o.sz,k*al)})}

/* ---------- bed with a sick man (scenes 2 and 10) ---------- */
function bed2(x0,x1,fy,p,t,table){const k=(x1-x0)/840,a=cl(p),o={w:9,wob:1.2},X=v=>x0+v*k,Y=v=>fy-v*k;
 S(rr(x0-18*k,Y(340),38*k,340*k,16),Object.assign({},o,{p:cl(a/.35),seed:1}));
 S(rr(x1-16*k,Y(215),32*k,215*k,14),Object.assign({},o,{p:cl((a-.1)/.35),seed:2}));
 S([[x0+20*k,Y(118)],[x1-16*k,Y(118)]],Object.assign({},o,{p:cl((a-.2)/.35),seed:3,w:7}));
 S(rr(x0+22*k,Y(194),(x1-x0)-38*k,62*k,20),Object.assign({},o,{p:cl((a-.3)/.35),seed:4,w:7}));
 S(rr(X(50),Y(256),200*k,62*k,28),Object.assign({},o,{p:cl((a-.5)/.3),seed:5,w:7}));S([[X(95),Y(236)],[X(150),Y(242)]],{w:4,a:.4*cl((a-.7)*3),seed:6,wob:.4});
 const hr=58*k,hc=[X(150),Y(256)-hr*.8],B=[[236,258],[330,278],[440,284],[540,304],[610,296],[665,270],[725,288],[782,310],[812,268],[812,194]];
 g.save();g.globalAlpha=.62*cl((a-.7)*4);g.fillStyle='#3d2b52';g.beginPath();g.moveTo(X(236),Y(194));B.forEach(q=>g.lineTo(X(q[0]),Y(q[1])));g.lineTo(X(812),Y(194));g.closePath();g.fill();g.restore();
 S(B.map(q=>[X(q[0]),Y(q[1])]),Object.assign({},o,{p:cl((a-.6)/.4),seed:7}));
 if(a>.85){[[330,236,360,200],[450,246,480,204],[560,262,590,208],[700,250,730,206]].forEach((q,i)=>S([[X(q[0]),Y(q[1])],[X(q[2]),Y(q[3])]],{col:BL,w:5,a:.3,seed:8+i,wob:.3}));
  S([[X(240),Y(262)],[X(262),Y(238)],[X(246),Y(204)]],{w:5,a:.6,seed:12,wob:.4})}
 if(table&&a>.4){const tx=x1+36;S(rr(tx,fy-150,104,150,10),{w:7,p:cl((a-.4)*2),seed:13,wob:.8});S([[tx+12,fy-100],[tx+92,fy-100]],{w:5,a:.5,seed:14,wob:.3});S(circ(tx+52,fy-76,5,6),{w:5,seed:15,wob:.2});
  if(a>.8){S(rr(tx+10,fy-196,58,46,6),{w:6,seed:16,wob:.6});S([[tx+26,fy-196],[tx+34,fy-224],[tx+44,fy-196]],{w:5,seed:17,wob:.5});S(rr(tx+76,fy-190,22,40,5),{col:BL,w:5,seed:18,wob:.5});S([[tx+80,fy-170],[tx+94,fy-170]],{col:BL,w:4,a:.7,seed:19,wob:.2})}}
 return{hc:hc,hr:hr,k:k,X:X,Y:Y}}
function lying2(b,t,al,sad){const hc=b.hc,hr=b.hr;S(circ(hc[0],hc[1],hr,40,-1.7,-1.7+TAU),{w:9,a:al,seed:2,wob:1.2});mgFace(hc,hr,WH,al,0,3);eyes(hc,hr,0,0,WH,al,1,0);
 S(rr(hc[0]-hr*.62,hc[1]-hr*1.12,hr*1.24,hr*.46,10),{col:BL,w:5,a:al*.9,seed:3,wob:.4});
 S([[hc[0]+hr*.12,hc[1]+hr*.56],[hc[0]+hr*1.5,hc[1]+hr*.98]],{col:RD,w:6,a:al,seed:44,wob:.3});S(circ(hc[0]+hr*1.55,hc[1]+hr*1.0,5,6),{col:RD,w:6,a:al,seed:45,wob:.2});
 S([[hc[0]+hr*.85,hc[1]+hr*.8],[b.X(236),b.Y(262)]],{w:9,a:al,seed:46,wob:.6});
 if(sad)for(let i=0;i<2;i++){const dy=((t*.9+i*.5)%1)*60;S([[hc[0]-hr*(.9+i*.3),hc[1]-hr*.4+dy],[hc[0]-hr*(.9+i*.3),hc[1]-hr*.4+dy+14]],{col:BL,w:7,a:al*(1-P(dy,40,20)),seed:50+i,wob:.2})}}

/* ---------- scene 1: broken bone? fine. ---------- */
function z1(t){CAM={x:540+Math.sin(t*.5)*8,y:720,z:1+.05*P(t,0,5)};camT();
 const gy=1050,ph=t*5.2,lg=legs(ph,1),k=ez(t,.2,1.2),by=Math.abs(Math.sin(ph))*-10;
 gnd(gy,ez(t,.1,.8),t*170,1);
 const hip=[540,gy-172*1.3+by];
 mg({x:hip[0],y:hip[1],s:1.3,p:k,seed:3,legL:lg.L,legR:lg.R,armL:[-.32+.14*Math.sin(ph+Math.PI),-.18],armR:[.34+.14*Math.sin(ph),.22]});
 if(k>.6)for(let i=0;i<4;i++){const u=(t*2.4+i*.25)%1;puff(500-u*150,gy-8,u,.6)}
 if(t>2.5){const q=ez(t,2.5,.6),kn=limb(hip,lg.R[0],lg.R[1],86,86,1.3),a=kn[1],b=kn[2];
  for(let i=0;i<4;i++){const u=.25+i*.17,px=lp(a[0],b[0],u),py=lp(a[1],b[1],u);S([[px-17,py-5],[px+17,py+7]],{w:6,p:q,seed:70+i,wob:.5})}
  S([[lp(a[0],b[0],.38)+4,lp(a[1],b[1],.38)-10],[lp(a[0],b[0],.62)-6,lp(a[1],b[1],.62)+12]],{col:RD,w:6,p:q,seed:75,wob:.4})}
 const bp=pp(t,1.8,.7);if(bp>0)popAt(540,385,bp,()=>{bone(540,385,260,-.12,1,1,P(t,2.6,.4))});
 if(t>3.0){const a=ez(t,3.0,.6);CT('استخوان شکسته؟ مهم نیست.',540,480-lp(14,0,a),46,YE,a)}
 if(t>3.2){const a=ez(t,3.2,.3)*(.5+.5*Math.sin(t*6));sparkle(420,350,14,a,500,t);sparkle(660,420,11,a*.9,502,-t)}}

/* ---------- scene 2: ...acts like he is dying ---------- */
function z2(t){const q=P(t,5.0,5.4);CAM={x:lp(560,520,q),y:710,z:1.0+.06*q};camT();
 const fy=1020,b=bed2(90,880,fy,ez(t,5.1,1.1),t,true);
 if(t>5.9)lying2(b,t,ez(t,5.9,.4),t>8.0);
 if(t>6.1)reveal('«دارم می‌میرم...»',330,fy-560,56,P(t,6.1,1.1),ez(t,6.1,.3));
 if(t>6.8&&t<8.0){const a=1-P(t,7.4,.6),hc=b.hc;for(let i=0;i<5;i++){const an=-.5+i*.38;S([[hc[0]+Math.cos(an)*b.hr*1.7,hc[1]-b.hr*.3+Math.sin(an)*b.hr*1.7],[hc[0]+Math.cos(an)*b.hr*2.2,hc[1]-b.hr*.3+Math.sin(an)*b.hr*2.2]],{w:6,a:a,seed:230+i,wob:.3})}
  popAt(hc[0]+330,hc[1]-60,pp(t,6.8,.4),()=>CT('آچی!',hc[0]+330,hc[1]-60,60,YE,a))}
 tissues(t,6.6,b.hc[0]+70,b.hc[1]-50,1);
 gnd(fy,ez(t,5.1,.8),0,.6)}

/* ---------- scene 3: just a joke... but there is a biological reason ---------- */
function z3(t){const q=P(t,10.45,4.7);CAM={x:lp(520,560,q),y:720,z:1+.05*q};camT();
 const gy=1050,mx=lp(540,380,ez(t,12.6,.9)),hx=ez(t,10.5,1.0),ar=ez(t,12.6,.7);
 gnd(gy,ez(t,10.5,.7),0,1);
 mg({x:mx,y:gy-172*1.15,s:1.15,p:hx,seed:5,armL:[-.5+(-.3)*ar,1.45-1.2*ar],armR:[.5,-1.45]});
 [0,1,2].forEach(i=>{const a=pp(t,11.15+i*.42,.4)*(1-P(t,12.55,.3));if(a>0){popAt(mx-120+i*118,540-(i===1?40:0)+Math.sin(t*5+i)*5,a,()=>CT('ها!',mx-120+i*118,540-(i===1?40:0),84,YE,1,(i-1)*.18))}});
 if(t>12.7){dna(800,430,1000,t,ez(t,12.8,1.2),ez(t,12.7,.4));tag('زیست‌شناسی',800,370,BL,pp(t,13.5,.5),34)}}

/* ---------- scene 4: serious injury -> adrenaline + endorphins -> pain drops ---------- */
function z4(t){const q=P(t,15.2,13.8),zm=ez(t,15.2,3);CAM={x:lp(480,560,ez(t,23.5,3.5)),y:lp(740,730,q),z:lp(1,1.1,zm)+.03*q};camT();
 const gy=1050,hy=gy-172*1.15,mx=380,e=ENV[Math.min(ENV.length-1,Math.floor(TR*30))]||0;
 gnd(gy,ez(t,15.3,.7),0,1);
 const inj=ez(t,16.2,.5)*(1-ez(t,24.2,2.2)),ph=P(t,19.9,.8)*(1-P(t,27.3,1.0));
 if(inj>.01){const gl=g.createRadialGradient(mx+30,gy-70,10,mx+30,gy-70,200),pl=.75+.25*Math.sin(t*7);gl.addColorStop(0,'rgba(255,70,60,'+.5*inj*pl+')');gl.addColorStop(1,'rgba(255,70,60,0)');g.fillStyle=gl;g.fillRect(mx-250,gy-300,560,400);
  for(let i=0;i<2;i++){const u=((t-16.2)*.9+i*.5)%1;if(t>16.2&&t<19.6)S(circ(mx+30,gy-80,40+u*130,24),{col:RD,w:6,a:.55*(1-u)*inj,seed:320+i,wob:.5})}}
 if(ph>.01){const hc=[mx,hy-126*1.15-44*1.15-5],gl=g.createRadialGradient(hc[0],hc[1],20,hc[0],hc[1],230);gl.addColorStop(0,'rgba(255,216,74,'+(.38+.2*e)*ph+')');gl.addColorStop(1,'rgba(255,216,74,0)');g.fillStyle=gl;g.fillRect(hc[0]-260,hc[1]-260,520,520)}
 mg({x:mx,y:hy,s:1.15,p:ez(t,15.3,1.0),seed:6,armL:[-.25,-.1],armR:[.25,.1]});
 if(inj>.01){tag('آسیب!',mx+230,gy-90,RD,1,44,inj);S([[mx+12,gy-150],[mx+52,gy-110]],{col:RD,w:7,a:inj,seed:310,wob:.3});S([[mx+52,gy-150],[mx+12,gy-110]],{col:RD,w:7,a:inj,seed:311,wob:.3})}
 if(ph>.01){const path=[[mx+20,gy-6],[mx+30,gy-170],[mx,hy+10],[mx,hy-126*1.15*.8],[mx,hy-126*1.15-70]];
  for(let i=0;i<16;i++){const u=((t*.28+i/16)%1),s=u*(path.length-1),j=Math.min(path.length-2,Math.floor(s)),f=s-j,px=lp(path[j][0],path[j+1][0],f)+Math.sin(i*2.1+t*3)*20,py=lp(path[j][1],path[j+1][1],f);
   S(circ(px,py,12,8),{col:i%2?PK:YE,w:11,a:ph*cl(u*5)*(1-P(u,.9,.1)),seed:200+i,wob:.5})}
  S(circ(mx,hy-126*1.15-44*1.15-5,44*1.15*1.5+Math.sin(t*6)*4,32),{col:YE,w:6,a:.55*ph,seed:300,wob:1.2});
  [[770,430,YE],[770,505,PK]].forEach((c,i)=>{if(t>20.4+i*1)S([[690,c[1]],[mx+70,hy-200+i*60]],{col:c[2],w:4,a:.35*ph,dash:[10,12],seed:330+i,wob:.4})})}
 if(t>19.7){const a=ez(t,19.7,.5);CT('مسکن‌های طبیعی',760,350,40,DM,a);tag('آدرنالین',770,430,YE,pp(t,20.4,.5),36);tag('اندورفین',770,505,PK,pp(t,21.4,.5),36)}
 const lv=lp(0,.95,ez(t,16.5,1.1))*(1-ez(t,24.3,2.4)*.87);
 meter(720,590,92,440,lv,RD,'درد',ez(t,16.4,.8));
 if(t>26.4){const a=ez(t,26.4,.5);sparkle(mx+120,hy-300,12,a*(.6+.4*Math.sin(t*6)),340,t)}}

/* ---------- scene 5: a soldier runs with a grenade, loses a leg below the knee, keeps running, throws it ---------- */
const TS5=32.3,TT5=33.9,TL5=34.85;
function figC(o){const s=o.s||2,p=o.p===undefined?1:o.p,col=WH,al=1,sd=o.seed||1,ta=o.tAng||0,w=10*(s/2),hip=[o.x,o.y],up=[Math.sin(ta),-Math.cos(ta)],tl=126*s,neck=[hip[0]+up[0]*tl,hip[1]+up[1]*tl],hr=44*s;
 const hc=[neck[0]+up[0]*(hr+4*s),neck[1]+up[1]*(hr+4*s)],sh=[hip[0]+up[0]*tl*.82,hip[1]+up[1]*tl*.82],aL=o.armL,aR=o.armR,lL=o.legL,lR=o.legR,o1={col:col,a:al,w:w,seed:sd,wob:2.4*(s/2)};
 S(circ(hc[0],hc[1],hr,40,-1.7,-1.7+TAU),Object.assign({},o1,{p:cl(p/.25)}));S([neck,hip],Object.assign({},o1,{p:cl((p-.2)/.25)}));
 S(limb(sh,aL[0],aL[1],62,58,s),Object.assign({},o1,{p:cl((p-.42)/.2),seed:sd+1}));S(limb(sh,aR[0],aR[1],62,58,s),Object.assign({},o1,{p:cl((p-.5)/.2),seed:sd+2}));
 S(limb(hip,lL[0],lL[1],86,86,s),Object.assign({},o1,{p:cl((p-.66)/.2),seed:sd+3}));
 const rp=limb(hip,lR[0],lR[1],86,86,s);S(o.cutShin?[rp[0],rp[1]]:rp,Object.assign({},o1,{p:cl((p-.78)/.22),seed:sd+4}));
 if(p>.4)mgFace(hc,hr,col,al,ta,sd);if(p>.2)eyes(hc,hr,0,0,col,al,1,ta);
 return{hc:hc,hr:hr,neck:neck,hip:hip,sh:sh,rp:rp,hand:limb(sh,aR[0],aR[1],62,58,s)[2]}}
function pose5(t,s){const ph=t*8.6,lg=legs(ph,1.25),cut=t>=TS5;let aR=[.9-.4*Math.sin(ph),.7];
 if(t>TT5-.28&&t<TT5+.5){const w1=ez(t,TT5-.28,.3),w2=ez(t,TT5+.02,.3);aR=[lp(lp(.9,-1.3,w1),1.9,w2),lp(.7,-.3,w1)*(1-w2)+.3*w2]}
 return{ph:ph,lg:lg,hy:1050-172*s-Math.abs(Math.sin(ph))*16+(cut?16*Math.max(0,Math.sin(ph+1)):0),ta:.28+(cut?.05*Math.sin(ph):0),aR:aR,aL:[-.9+.4*Math.sin(ph),-.5]}}
function grenade(cx,cy,r,rot,al){const R=q=>[cx+q[0]*Math.cos(rot)-q[1]*Math.sin(rot),cy+q[0]*Math.sin(rot)+q[1]*Math.cos(rot)];
 g.save();g.translate(cx,cy);g.rotate(rot);g.globalAlpha=al;g.fillStyle=GN;g.beginPath();g.ellipse(0,0,r*.82,r,0,0,TAU);g.fill();g.fillStyle='#2d7a2d';g.fillRect(-r*.3,-r*1.32,r*.6,r*.5);g.restore();
 S(ell(0,0,r*.82,r,20).map(R),{col:GR,w:7,a:al,seed:1,wob:.2,steady:true});S([R([-r*.3,-r*1.32]),R([r*.3,-r*1.32]),R([r*.3,-r*.8])],{col:GR,w:6,a:al,seed:2,steady:true});
 S([R([r*.25,-r*1.25]),R([r*1.0,-r*1.05])],{col:GR,w:5,a:al,seed:3,steady:true});S(circ(R([r*1.12,-r*.95])[0],R([r*1.12,-r*.95])[1],r*.3,10),{col:GR,w:5,a:al,seed:4,steady:true});
 S([R([-r*.7,-r*.25]),R([r*.7,-r*.25])],{col:'#2d7a2d',w:5,a:al*.8,seed:5,steady:true});S([R([-r*.7,r*.3]),R([r*.7,r*.3])],{col:'#2d7a2d',w:5,a:al*.8,seed:6,steady:true})}
function z5(t){const s=1.15,gy=1050,cut=t>=TS5,u=Math.max(0,t-TS5),k=ez(t,29.4,1.0),po=pose5(t,s);
 CAM={x:lp(500,560,P(t,29,7))+N1(t*9)*1.6,y:730+N1(t*7)*1.6,z:1.06};camT();
 gnd(gy,ez(t,29.2,.6),t*700,1);
 for(let i=0;i<6;i++){const v=(t*1.7+i*.31)%1,a=ez(t,30.3,.5)*(1-P(v,.55,.45))*.8,yy=po.hy-270+i*62;S([[330-v*300,yy],[330-v*300-lp(150,70,v),yy]],{w:6,a:a,seed:400+i,wob:.8})}
 if(k>.6)for(let i=0;i<5;i++){const v=(t*5+i*.2)%1;puff(505-v*150,gy-8,v,.6)}
 const f=figC({x:560,y:po.hy,s:s,p:k,seed:7,tAng:po.ta,legL:po.lg.L,legR:po.lg.R,armL:po.aL,armR:po.aR,cutShin:cut});
 /* solid green helmet */
 if(k>.7){const hc=f.hc,hr=f.hr,ta=po.ta,a0=Math.PI+.3+ta,a1=2*Math.PI-.3+ta,hp=circ(hc[0],hc[1],hr*1.16,24,a0,a1),a=cl((k-.7)*4);
  g.save();g.globalAlpha=a;g.fillStyle=GN;g.beginPath();hp.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.closePath();g.fill();g.restore();
  S(hp.concat([hp[0]]),{col:'#7fe07f',w:8,a:a,seed:81,wob:.3,steady:true});const c=Math.cos(ta),sn=Math.sin(ta),B=(dx,dy)=>[hc[0]+dx*c-dy*sn,hc[1]+dx*sn+dy*c];S([B(-hr*1.28,-hr*.42),B(hr*1.38,-hr*.42)],{col:'#7fe07f',w:9,a:a,seed:82,steady:true})}
 /* grenade in hand, then thrown to the right */
 if(k>.8){if(t<TT5+.03){const gx=f.hand[0]+10,gy2=f.hand[1]+6;grenade(gx,gy2,24,.4+.2*Math.sin(po.ph),1)}
  else if(t<TL5){const p0=pose5(TT5,s),fh=figC.call(null,{x:560,y:p0.hy,s:s,p:0,seed:7,tAng:p0.ta,legL:p0.lg.L,legR:p0.lg.R,armL:p0.aL,armR:p0.aR}),rx=fh.hand[0]+10,ry=fh.hand[1]+6,v=(t-TT5-.03)/(TL5-TT5-.03);
   grenade(lp(rx,985,v),lp(ry,gy-26,v)-330*4*v*(1-v),24,.4+v*9,1)}
  else{const v=P(t,TL5,.5);if(v<1){for(let i=0;i<9;i++){const a=-Math.PI+i*Math.PI/8,r0=14+30*v,r1=r0+40*Math.sin(v*Math.PI)+16;S([[985+Math.cos(a)*r0,gy-30+Math.sin(a)*r0],[985+Math.cos(a)*r1,gy-30+Math.sin(a)*r1]],{col:i%2?YE:WH,w:7,a:1-v,seed:800+i,wob:.3})}
   S(circ(985,gy-34,30+60*v,20),{col:GR,w:6,a:.6*(1-v),seed:810,wob:.6})}}}
 if(t>31.4){const q=ez(t,31.4,.5);[[f.sh[0]+46,f.sh[1]+22],[f.hip[0]-20,f.hip[1]-70]].forEach((w,i)=>{S([[w[0]-16,w[1]-8],[w[0]+16,w[1]+8]],{w:6,p:q,seed:90+i,wob:.3});S([[w[0]-16,w[1]+8],[w[0]+16,w[1]-8]],{w:6,p:q,seed:93+i,wob:.3});S(circ(w[0],w[1],26,12),{col:RD,w:6,p:q,a:.9,seed:96+i,wob:.4})})}
 if(cut){const kn=f.rp[1],bu=P(u,0,.45);
  if(bu<1)for(let i=0;i<7;i++){const a=-1.1+i*.5,r0=24,r1=24+66*oC(bu);S([[kn[0]+Math.cos(a)*r0,kn[1]+Math.sin(a)*r0],[kn[0]+Math.cos(a)*r1,kn[1]+Math.sin(a)*r1]],{col:RD,w:8,a:1-bu,seed:520+i,wob:.4})}
  S(circ(kn[0],kn[1],6,8),{col:RD,w:9,seed:530,wob:.2});
  const p0=pose5(TS5,s),fh=figC({x:560,y:p0.hy,s:s,p:0,seed:7,tAng:p0.ta,legL:p0.lg.L,legR:p0.lg.R,armL:p0.aL,armR:p0.aR}),k0=fh.rp[1],ft=fh.rp[2];
  const need=gy-12-k0[1],ul=(380+Math.sqrt(380*380+4*750*need))/1500,uu=Math.min(u,ul),ty=-380*uu+750*uu*uu,tx=-150*uu-(u>ul?700*(u-ul):0),th=-10.47*uu,c=Math.cos(th),sn=Math.sin(th);
  const T=q=>{const dx=q[0]-k0[0],dy=q[1]-k0[1];return[k0[0]+dx*c-dy*sn+tx,k0[1]+dx*sn+dy*c+ty]};
  S([T(k0),T(ft)],{w:7,seed:540,wob:.4});S(circ(T(k0)[0],T(k0)[1],6,8),{col:RD,w:8,seed:541,wob:.2})}
 if(t>33.0){const a=ez(t,33.0,.5);CT('به جنگیدن ادامه داد',560,520-lp(12,0,a),52,YE,a)}}

/* ---------- scene 6: priority: survival over pain ---------- */
function z6(t){CAM={x:540,y:lp(740,720,P(t,36,4.5)),z:lp(1.04,1.0,P(t,36,4.5))};camT();
 CT('اولویت:',540,330,42,DM,ez(t,36.5,.5));cloud(540,490,250,125,ez(t,36.5,.9),1);
 meter(330,700,130,330,.86*ez(t,37.3,1.1),GR,'بقا',ez(t,36.8,.8));
 meter(660,700,130,330,.10*ez(t,38.5,.8),RD,'درد',ez(t,37.0,.8));
 const gt=ez(t,38.4,.5);if(gt>0)S([[505,830],[575,880],[505,930]],{col:YE,w:12,p:gt,seed:60,wob:.3});
 const pu=P(t,38.5,.5)*(1-P(t,38.9,.6));if(pu>0)S(rr(645,688,160,356,18),{col:RD,w:6,a:.5*pu,seed:9,wob:1});
 if(t>37.4)sparkle(395,670,12,ez(t,37.4,.3)*(.6+.4*Math.sin(t*6)),61,t)}

/* ---------- scene 7: testosterone and oestrogen shape the immune response ---------- */
function z7(t){const q=P(t,40.5,13.2);CAM={x:540,y:730,z:1.04+.03*q};camT();
 const gy=1030,hy=gy-172*1.05,e1=ez(t,40.6,1.0),mx=300,wx=780;
 gnd(gy,ez(t,40.6,.8),0,1);
 const sway=Math.sin(t*1.7)*.04;
 mg({x:mx,y:hy,s:1.05,p:e1,seed:8,armL:[-.25+sway,-.1],armR:[.25-sway,.1]});
 wm({x:wx,y:hy,s:1.05,p:ez(t,41.0,1.0),seed:9,armL:[-.22,-.1],armR:[.22,.1]});
 tag('تستوسترون',mx,370,BL,pp(t,42.7,.5),36);
 if(t>47.2){const a=ez(t,47.2,.5);CT('واکنش ایمنی',mx,448,34,WH,a*.9)}
 const sa=ez(t,47.6,.9),pu=.75+.25*Math.sin(t*5);shield(mx,hy-60,330,520,BL,sa,pu,11);
 if(sa>=1)for(let i=0;i<3;i++){const an=t*.9+i*TAU/3;ab(mx+Math.cos(an)*105,hy-60+Math.sin(an)*150,14,an+1.6,BL,.9)}
 for(let i=0;i<5;i++){const t0=48.3+i*.55,u=P(t,t0,1.0);if(u<=0||u>=1)continue;const hit=u<.55?u/.55:1,ang=-2.6+i*.35,d=lp(340,185,oC(hit))+(u>.55?(u-.55)/.45*150:0),px=mx+Math.cos(ang)*d,py=hy-60+Math.sin(ang)*d*1.35;virus(px,py,19,t,(1-P(u,.8,.2)),500+i*20)}
 if(t>51.35){tag('استروژن',wx,370,PK,pp(t,51.35,.5),36);CT('واکنش ایمنی',wx,448,34,WH,ez(t,51.9,.5)*.9);shield(wx,hy-60,330,520,PK,ez(t,52.0,.9),.75+.25*Math.sin(t*5+1),12);
  if(t>52.9)for(let i=0;i<3;i++){const an=-t*.9+i*TAU/3;ab(wx+Math.cos(an)*105,hy-60+Math.sin(an)*150,14,an+1.6,PK,ez(t,52.9,.4)*.9)}}}

/* ---------- scene 8: thermometers ---------- */
function z8(t){const q=P(t,53.7,7.3);CAM={x:540,y:730,z:1.02+.05*q};camT();
 const gy=1030,hy=gy-172*1.05,mx=230,wx=850;
 gnd(gy,ez(t,53.8,.7),0,1);
 S([[540,360],[540,1030]],{w:5,a:.55*ez(t,54.4,.8),dash:[18,18],seed:15,wob:1.2});
 mg({x:mx,y:hy,s:1.05,p:ez(t,53.9,1.0),seed:8,armL:[-.25,-.1],armR:[.25,.1]});
 wm({x:wx,y:hy,s:1.05,p:ez(t,54.2,1.0),seed:9,armL:[-.22,-.1],armR:[.22,.1]});
 thermo(mx+190,420,330,.9*ez(t,55.8,1.7),RD,ez(t,55.0,.7),1,31);
 thermo(wx-190,420,330,.42*ez(t,57.3,1.5),YE,ez(t,56.9,.7),1,32);
 const hm=ez(t,56.2,.6);if(hm>0)for(let i=0;i<3;i++)S(wave(mx-70+i*70,hy-330,mx-70+i*70,hy-420,10,14,t*5+i),{col:RD,w:6,a:.6*hm,seed:350+i,wob:.2});
 const hw=ez(t,57.8,.6);if(hw>0)for(let i=0;i<2;i++)S(wave(wx-35+i*70,hy-330,wx-35+i*70,hy-410,5,14,t*2+i),{col:YE,w:6,a:.5*hw,seed:360+i,wob:.2});
 if(t>56.4)for(let i=0;i<2;i++){const dy=((t*.9+i*.5)%1)*70;S([[mx-62-i*14,hy-300+dy],[mx-62-i*14,hy-300+dy+16]],{col:BL,w:7,a:1-P(dy,45,25),seed:370+i,wob:.2})}}

/* ---------- scene 9: chart men vs women ---------- */
function z9(t){const q=P(t,61,8);CAM={x:lp(520,560,q),y:720,z:1+.04*q};camT();
 CT('پژوهش‌ها نشان می‌دهند...',540,380,44,DM,ez(t,62.3,.6));
 const ox=240,oy=1000,ap=ez(t,62.8,.9);
 if(ap>=1)[620,740,860].forEach((yv,i)=>S([[ox+10,yv],[900,yv]],{w:4,a:.14,dash:[8,16],seed:26+i,wob:.2}));
 S([[ox,oy],[ox,520]],{w:8,p:ap,seed:21,wob:1.4});S([[ox,oy],[900,oy]],{w:8,p:ap,seed:22,wob:1.4});
 if(t>63.2)CT('علائم',190,760,34,WH,ez(t,63.2,.5),-Math.PI/2);
 const m=ez(t,63.9,1.5),w=ez(t,65.1,1.1),bx=(x0,wd,h0,col,p,sd)=>{if(p<=0)return;const h=h0*p;g.save();g.globalAlpha=.9;g.fillStyle=col;g.fillRect(x0,oy-h,wd,h);g.restore();S(rr(x0,oy-h,wd,h,6),{col:col,w:5,a:.9,seed:sd,wob:.6})};
 bx(330,170,430,BL,m,23);bx(640,170,230,PK,w,24);
 CT('مردان',415,1050,36,WH,ez(t,63.5,.5));CT('زنان',725,1050,36,WH,ez(t,63.5,.5));
 for(let i=0;i<6;i++){const a=ez(t,65.9+i*.18,.5);if(a<=0)continue;const px=i<4?330+i*58:640+(i-4)*70;virus(px+Math.sin(t*1.4+i)*8,i<4?500+Math.sin(t*2+i)*10:700+Math.sin(t*2+i)*10,17,t,a,600+i*20)}
 const hl=P(t,66.9,.5)*(1-P(t,68.2,.6));if(hl>0)S(rr(322,oy-452,186,452,8),{col:YE,w:6,a:.6*hl,seed:25,wob:.8});
 const ua=ez(t,67.0,.4);if(ua>0){const bob=Math.sin(t*5)*6;S([[580,640+bob],[580,560+bob]],{col:YE,w:9,a:ua,seed:27,wob:.2});S([[550,590+bob],[580,556+bob],[610,590+bob]],{col:YE,w:9,a:ua,seed:28,wob:.2})}}

/* ---------- scene 10: "I'm dying of a cold" - drama vs exaggeration ---------- */
function z10(t){CAM={x:540,y:720,z:1.0+.04*P(t,69,8.7)};camT();
 const fy=1020,b=bed2(60,730,fy,ez(t,69.1,.9),t,false);
 lying2(b,t,ez(t,69.4,.4),t>72);
 tissues(t,70.0,b.hc[0]+60,b.hc[1]-50,.9);
 if(t>71.8)reveal('«دارم می‌میرم...»',330,fy-440,50,P(t,71.8,1.0),ez(t,71.8,.3));
 meter(820,540,100,430,.95*ez(t,72.3,1.5),YE,'درام',ez(t,72.0,.7));
 if(t>73.8)sparkle(870,520,13,ez(t,73.8,.3)*(.6+.4*Math.sin(t*6)),70,t);
 const a=pp(t,75.0,.55);if(a>0)popAt(440,400,a,()=>{tag('اغراق؟',440,400,PK,1,76)});
 if(t>75.6&&t<77.3)g.translate(N1(t*30)*3,N1(t*37)*2)}

/* ---------- scene 11: two different reactions ---------- */
function z11(t){const q=P(t,77.7,9.7);CAM={x:540,y:720,z:1+.03*q};camT();
 const dv=ez(t,78.0,.8)*(1-ez(t,84.0,.5));S([[540,380],[540,1010]],{w:5,a:.5*dv,dash:[18,18],seed:15,wob:1.2});
 tag('آسیب',290,420,RD,pp(t,79.4,.5),44);bone(290,610,230,-.12,ez(t,79.8,.8),1,P(t,80.6,.4));
 const a1=ez(t,80.9,.4);S([[290,680],[290,720]],{col:RD,w:7,a:a1,seed:44,wob:.2});S([[272,706],[290,726],[308,706]],{col:RD,w:7,a:a1,seed:45,wob:.2});
 meter(240,740,100,250,.85*ez(t,81.0,1.2),RD,'درد',ez(t,80.8,.6));
 tag('عفونت',790,420,GR,pp(t,81.4,.5),44);if(t>81.6)virus(790,610,58,t,ez(t,81.6,.6),700);
 const a2=ez(t,82.3,.4);S([[790,690],[790,730]],{col:GR,w:7,a:a2,seed:46,wob:.2});S([[772,716],[790,736],[808,716]],{col:GR,w:7,a:a2,seed:47,wob:.2});
 thermo(790,750,170,.85*ez(t,82.6,1.2),YE,ez(t,82.2,.6),1,33);CT('بیماری',790,1010,34,WH,ez(t,82.7,.5));
 const k=pp(t,84.1,.7);if(k>0)popAt(540,780,k,()=>{S([[480,730],[600,730]],{col:YE,w:14,seed:41,wob:.5});S([[480,820],[600,820]],{col:YE,w:14,seed:42,wob:.5});S([[580,690],[500,860]],{col:YE,w:14,seed:43,wob:.5})});
 if(t>84.5)sparkle(640,700,13,ez(t,84.5,.3)*(.6+.4*Math.sin(t*6)),48,t);
 GA=1-P(t,86.8,.6)}
const SC=[z1,z2,z3,z4,z5,z6,z7,z8,z9,z10,z11].map(f=>function(t,tl){TR=t;GA=1;f(INV(t))});
