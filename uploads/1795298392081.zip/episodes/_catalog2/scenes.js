/* CATALOG 2 (lib L2): visual props added after episode coldman. Render one frame to get the sheet. */
const HUD_END=0,CRT_T0=9999,WIN=[[0,10]],GLW=[];
function DMIN(t){return 0}
function zCatalog2(t){CAM={x:540,y:720,z:1};camT();
 const sc=(k,fn)=>(t)=>{g.save();g.scale(k,k);fn(t);g.restore()};
 const R_='#ff5a4a',B_='#6ea8ff';
 const cells=[
  ['خط زمین متحرک','gnd',t=>{g.save();g.scale(.3,.3);g.translate(-540,0);gnd(0,1,t*120,1);g.restore()}],
  ['استخوان','bone',sc(.5,t=>bone(0,0,260,-.12,1,1,0))],
  ['ویروس','virus',sc(3,t=>virus(0,0,19,t,1,500))],
  ['سپر','shield',sc(.35,t=>shield(0,0,330,520,B_,1,1,11))],
  ['دماسنج','thermo',sc(.4,t=>thermo(0,-200,330,.6,R_,1,1,31))],
  ['دی‌ان‌ای','dna',sc(.3,t=>dna(0,-300,300,t,1,1))],
  ['دستمال','tissue',t=>tissue(0,0,.3,80,1)],
  ['ابر فکر','cloud',sc(.5,t=>cloud(0,0,250,125,1,1))],
  ['جرقه','sparkle',t=>sparkle(0,0,40,1,3,0,YE)],
  ['پوف دود','puff',t=>{puff(-90,0,.2,1);puff(0,0,.5,1);puff(90,0,.8,1)}],
  ['پادتن','ab',t=>ab(0,0,60,0,WH,1)],
  ['نوار درد','meter',sc(.4,t=>meter(-46,-220,92,440,.6,R_,'درد',1,1))],
  ['برچسب','tag',t=>tag('برچسب',0,0,B_,1,34,1)],
  ['نارنجک','grenade',t=>grenade(0,0,50,.4,1)],
  ['تخت و میز','bed2',sc(.3,t=>{bed2(-395,395,100,1,t,true)})],
  ['تخت + بیمار','bed2 lying2',sc(.3,t=>{const b=bed2(-395,395,100,1,t,true);lying2(b,t,1,true)})]
 ];
 CT('کتابخانه‌ی مرد گچی — آبجکت‌ها (۲)',400,235,40,YE,1);
 cells.forEach((c,i)=>{const col=i%3,row=Math.floor(i/3),cx=180+col*360,cy=380+row*265;
  S([[cx-165,cy-120],[cx+165,cy-120],[cx+165,cy+135],[cx-165,cy+135],[cx-165,cy-120]],{w:3,a:.18,steady:true,wob:0,seed:900+i});
  g.save();g.translate(cx,cy-10);c[2](t);g.restore();
  CT(c[0],cx,cy+98,28,WH,1);CT(c[1],cx,cy+126,20,'#9d9a90',1)})}
const SC=[zCatalog2];
